import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'
import Fourthpage from './components/Fourth.jsx'
import Thirdpage from './components/Third.jsx'
import Fifthpage from './components/Fifth.jsx'
import Sixthpage from './components/Sixth.jsx'
import Seventhpage from './components/Seventh.jsx'
import Secondpage from './components/Second.jsx'
import Firstpage from './components/First.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App/>
  </React.StrictMode>,
)
