import React from 'react'
import './App.css'
import Firstpage from './components/First'
import Secondpage from './components/Second'
import Thirdpage from './components/Third'
import Fourthpage from './components/Fourth'
import Fifthpage from './components/Fifth'
import Sixthpage from './components/Sixth'
import Seventhpage from './components/Seventh'

function App() {

  return (
<div className="global_container_">
    <Firstpage/>
    <Secondpage/>
    <Thirdpage/>
    <Fourthpage/>
    <Fifthpage/>
    <Sixthpage/>
    <Seventhpage/>

    </div>
  )
}

export default App
