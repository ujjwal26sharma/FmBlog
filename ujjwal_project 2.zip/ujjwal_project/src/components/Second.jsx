import React from "react";

const Secondpage = () =>{
    return(
        <div className="footer">
    <div className="col-3">
      <img
        className="text-20"
        src="images/home_presenters_artists_b.png"
        alt="Home          Presenters           Artists            Blogs           Relationships            Events            Contests             Show Listings             Downloads            Photos"
        width={855}
        height={11}
        title="Home          Presenters           Artists            Blogs           Relationships            Events            Contests             Show Listings             Downloads            Photos"
      />
      <div className="row-3 group">
        <p className="text-21">Copyrights © FMBLOG 2013, All rights Reserved</p>
        <p className="text-22">created by psdfreebies.com</p>
      </div>
    </div>
  </div>  

    )
}

export default Secondpage