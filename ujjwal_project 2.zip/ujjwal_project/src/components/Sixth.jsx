import React from "react";

const Sixthpage = () =>{
    return(
        <div className="advertisment-bottom">
    <p className="text-62">advertisment</p>
    <div className="row-5 group">
      <img
        className="text-63"
        src="images/advertisment_space_2.png"
        alt="Advertisment Space"
        width={406}
        height={45}
        title="Advertisment Space"
      />
      <img
        className="text-64"
        src="images/728x90_2.png"
        alt="728x90"
        width={13}
        height={57}
        title="728x90"
      />
    </div>
  </div>
    )
}
export default Sixthpage;
