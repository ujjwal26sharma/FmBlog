import React from "react";

const Seventhpage = () =>{
    return(
        <div className="listen-to-easyfm group">
    <img
      className="text-65"
      src="images/listen_to_fmblog.png"
      alt="Listen to FMBLOG"
      width={155}
      height={15}
      title="Listen to FMBLOG"
    />
    <img
      className="layer-27"
      src="images/layer_27.png"
      alt=""
      width={189}
      height={13}
    />
    <div className="row-25 group">
      <img
        className="layer-26"
        src="images/layer_26.jpg"
        alt=""
        width={50}
        height={50}
      />
      <p className="text-66">
        “Easy fm is giving you the chance to become a radio presenter for a day!
        Listen to ‘real radio’ between 2 &amp; 4pm on easy fm to find out how
        other people are their impressing the nation with their talents! To
        participate, text the words ‘Real Radio’ and your name to 5474 on
        Safaricom or Zain.”
      </p>
    </div>
    <img
      className="layer-27-copy"
      src="images/layer_27_copy.png"
      alt=""
      width={196}
      height={9}
    />
    <img
      className="layer-38"
      src="images/layer_38.png"
      alt=""
      width={243}
      height={9}
    />
    <img
      className="layer-38-copy"
      src="images/layer_38.png"
      alt=""
      width={600}
      height={22}
    />
  </div>
    )
}
export default Seventhpage