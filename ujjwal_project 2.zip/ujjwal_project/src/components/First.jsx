import React from "react";

const Firstpage = () =>{
    return(

  <div className="bg">
    <div className="navigation">
      <div className="row-7 match-height group">
        <img
          className="shape-20"
          src="images/shape_20.png"
          alt=""
          width={210}
          height={105}
        />
        <div className="advertisment-top">
          <p className="advertisment">advertisment</p>
          <div className="row-2 group">
            <img
              className="text"
              src="images/advertisment_space.png"
              alt="Advertisment Space"
              width={406}
              height={45}
              title="Advertisment Space"
            />
            <img
              className="text-2"
              src="images/728x90.png"
              alt="728x90"
              width={13}
              height={57}
              title="728x90"
            />
          </div>
        </div>
      </div>
      <div className="row-19 group">
        <div className="shape-21-holder">
          <img
            className="home"
            src="images/home.png"
            alt="Home"
            width={40}
            height={11}
            title="Home"
          />
        </div>
        <div className="wrapper-19">
        <nav>
    <p className="text-3" >
        <a href="#">Presenters</a> &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        <a href="#">Artists</a> &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        <a href="#">Blogs</a> &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        <a href="#">Relationships</a> &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        <a href="#">Events</a> &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        <a href="#">Contests</a> &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        <a href="#">Schedule</a> &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        <a href="#">Downloads</a> &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        <a href="#">Photos</a>
    </p>
</nav>

          {/* <img
            className="text-3"
            
            src="images/presenters_artists_blogs_.png"
            alt="Presenters        Artists         Blogs        Relationships        Events        Contests        Schedule        Downloads        Photos"
            width={818}
            height={14}
            title="Presenters        Artists         Blogs        Relationships        Events        Contests        Schedule        Downloads        Photos"
          /> */}
          <img
            className="layer-48-copy-7"
            src="images/layer_48_copy_7.png"
            alt=""
            width={674}
            height={24}
          />
        </div>
      </div>
    </div>
    <div className="shape-23-holder">
      <img
        className="layer-29-copy"
        src="images/layer_29_copy.png"
        alt=""
        width={1500}
        height={205}
      />
      <div className="player">
        <div className="row-14 group">
          <img
            className="layer-10"
            src="images/layer_47_copy.jpg"
            alt=""
            width={26}
            height={40}
          />
          <div className="wrapper-13">
            <div className="group-12 group">
              <div className="shape-15-copy-4" />
              <div className="shape-15" />
              <div className="shape-15-copy" />
              <div className="shape-15-copy-2" />
              <div className="shape-15-copy-3" />
            </div>
            <img
              className="text-4"
              src="images/now_playing.png"
              alt="Now Playing"
              width={110}
              height={20}
              title="Now Playing"
            />
          </div>
        </div>
        <div className="col group">
          <div className="col-2">
            <div className="group-6 group">
              <img
                className="shape-4-copy-2"
                src="images/shape_4_copy_2.png"
                alt=""
              />
              <div className="col-21">
                <p className="text-5">Artist Name heading</p>
                <p className="text-6">Music album subheading title</p>
              </div>
            </div>
            <div className="group-7 group">
              <div className="row-15 group">
                <p className="text-7">
                  <span className="color00577d">Playing:</span> &nbsp;Song name
                </p>
                <div className="volume match-height group">
                  <img
                    className="icon"
                    src="images/icon.png"
                    alt=""
                    width={10}
                    height={11}
                  />
                  <div className="group-5 group">
                    <img
                      src="images/layer_21.png"
                      alt=""
                      width={6}
                      height={6}
                    />
                    <img
                      src="images/layer_21.png"
                      alt=""
                      width={6}
                      height={6}
                    />
                    <img
                      src="images/layer_21.png"
                      alt=""
                      width={6}
                      height={6}
                    />
                    <img
                      src="images/layer_21.png"
                      alt=""
                      width={6}
                      height={6}
                    />
                    <img
                      src="images/layer_21.png"
                      alt=""
                      width={6}
                      height={6}
                    />
                    <img
                      src="images/layer_21.png"
                      alt=""
                      width={6}
                      height={6}
                    />
                    <img
                      src="images/layer_31_copy_6.png"
                      alt=""
                      width={7}
                      height={7}
                    />
                    <img
                      src="images/layer_31_copy_6.png"
                      alt=""
                      width={7}
                      height={7}
                    />
                    <img
                      src="images/layer_31_copy_6.png"
                      alt=""
                      width={7}
                      height={7}
                    />
                    <img
                      src="images/layer_31_copy_6.png"
                      alt=""
                      width={7}
                      height={7}
                    />
                  </div>
                </div>
              </div>
              <p className="text-8">04:37</p>
              <div className="wrapper-20">
                <div className="shape-10" />
                <div className="shape-8" />
              </div>
            </div>
            <div className="row group">
              <p className="text-9">Previously Played:</p>
              <p className="text-10">Song name</p>
            </div>
          </div>
          <div className="buttons group">
            <img
              className="layer-16"
              src="images/layer_16.png"
              alt=""
              width={207}
              height={1}
            />
            <div className="row-26 no-space-between-inline-blocks">
              <img
                className="back"
                src="images/back.png"
                alt=""
                width={16}
                height={10}
              />
              <img
                className="layer-22"
                src="images/layer_22.jpg"
                alt=""
                width={2}
                height={18}
              />
              <img
                className="pause"
                src="images/pause.png"
                alt=""
                width={8}
                height={9}
              />
              <img
                className="layer-22-copy"
                src="images/layer_22.jpg"
                alt=""
                width={2}
                height={18}
              />
              <img
                className="play"
                src="images/play.png"
                alt=""
                width={14}
                height={16}
              />
              <img
                className="layer-22-copy-2"
                src="images/layer_22.jpg"
                alt=""
                width={2}
                height={18}
              />
              <div className="stop" />
              <img
                className="layer-22-copy-3"
                src="images/layer_22.jpg"
                alt=""
                width={2}
                height={18}
              />
              <img
                className="fwd"
                src="images/fwd.png"
                alt=""
                width={16}
                height={10}
              />
            </div>
          </div>
        </div>
      </div>
      <div className="header">
        <div className="bottom group">
          <div className="shape-52-copy-holder">
            <img
              className="shape-51-copy"
              src="images/shape_51_copy.png"
              alt=""
              width={14}
              height={14}
            />
          </div>
          <div className="shows2 group">
            <img className="shape-4" src="images/shape_4.png" alt="" />
            <div className="col-19">
              <p className="text-11">
                The early breakfast with
                <br />
                Gladys Gachanja
              </p>
              <p className="text-12">5 am - 6 am</p>
              <p className="text-13">
                Wake up early with Gladys every morning and you’re guaranteed
                inspiration..
              </p>
            </div>
          </div>
          <div className="shows1 group">
            <img
              className="shape-4-copy"
              src="images/shape_4_copy.png"
              alt=""
            />
            <div className="col-20">
              <p className="text-14">
                Listen, laugh &amp; learn with
                <br />
                &nbsp;Marcus &amp; Munene
              </p>
              <p className="text-15">6 am - 10 am</p>
              <p className="text-16">
                It’s fun, inspirational &amp; motivational. With relationship
                advice from a qualified..
              </p>
            </div>
          </div>
          <div className="shape-52-holder">
            <img
              className="shape-51"
              src="images/shape_51.png"
              alt=""
              width={14}
              height={14}
            />
          </div>
        </div>
        <div className="top group">
          <img
            className="text-17"
            src="images/no_one_ever_promised_you_.png"
            alt="No one ever promised you an easy life."
            width={339}
            height={21}
            title="No one ever promised you an easy life."
          />
          <p className="text-18">
            But there’s one readio station that does promise you easy listening.
            But there’s one readio station that does promise you easy listening.
            But there’s one readio station that does promise you easy listening.
          </p>
          <p className="text-19">View all</p>
        </div>
      </div>
    </div>
  </div>


    )
}
export default Firstpage