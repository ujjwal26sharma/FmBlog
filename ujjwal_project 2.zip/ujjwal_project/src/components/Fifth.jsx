import React from "react";

const Fifthpage = () =>{
    return(
        <div className="advertisment-4">
    <p className="advertisment-5">advertisment</p>
    <div className="col-9">
      <div className="shape-49-holder">
        <img
          className="advertisment-6"
          src="images/advertisment_3.png"
          alt="Advertisment"
          width={151}
          height={19}
          title="Advertisment"
        />
      </div>
      <div className="row-4 group">
        <img
          className="space-3"
          src="images/space_3.png"
          alt="Space"
          width={64}
          height={24}
          title="Space"
        />
        <img
          className="text-61"
          src="images/300x250.png"
          alt="300X250"
          width={67}
          height={13}
          title="300X250"
        />
      </div>
    </div>
  </div>
    )
}
export default Fifthpage