import React from "react";

const Thirdpage = () =>{
    return(

        <div className="facebook group">
    <div className="col-8">
      <img
        className="text-58"
        src="images/join_fmblog_on_facebook.png"
        alt="Join FMBLOG On Facebook"
        width={236}
        height={15}
        title="Join FMBLOG On Facebook"
      />
      <img
        className="layer-39"
        src="images/layer_39.jpg"
        alt=""
        width={317}
        height={394}
      />
    </div>
    <div className="twitter">
      <img
        className="layer-56"
        src="images/layer_56.png"
        alt=""
        width={176}
        height={44}
      />
      <div className="col-7">
        <div className="shape-47-holder">
          Mobile Boilerplate: a best practice baseline for your mobile Web app -
          <span className="color0094ce"> http://bit.ly/dRJO9f</span>
        </div>
        <div className="shape-47-copy-holder">
          Dummy text dropdo: a quick and simple file viewer online -{" "}
          <span className="color008ec7">http://dropdo.com</span>
        </div>
      </div>
      <div className="layer-53-holder">
        <img
          className="us"
          src="images/us.png"
          alt="us"
          width={20}
          height={13}
          title="us"
        />
      </div>
    </div>
    <img
      className="layer-61"
      src="images/layer_61.png"
      alt=""
      width={24}
      height={24}
    />
  </div>
    )
}
export default Thirdpage