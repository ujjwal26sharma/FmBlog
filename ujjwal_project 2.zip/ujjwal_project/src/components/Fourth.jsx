import React from "react";

const Fourthpage = () =>{
    return(
        <div className="content">
    <div className="latest-news">
      <div className="heading group">
        <img
          className="layer-46"
          src="images/layer_47_copy.jpg"
          alt=""
          width={26}
          height={40}
        />
        <img
          className="latest"
          src="images/latest.png"
          alt="Latest"
          width={54}
          height={15}
          title="Latest"
        />
      </div>
      <div className="tab">
        <img
          className="text-23"
          src="images/showbiz_music_funny.png"
          alt="Showbiz              Music               Funny"
          width={234}
          height={16}
          title="Showbiz              Music               Funny"
        />
      </div>
      <div className="row-10 match-height group">
        <div className="col-16">
          <div className="news1">
            <img
              className="layer-31"
              src="images/layer_31.jpg"
              alt=""
              width={160}
              height={74}
            />
            <p className="text-24">
              <strong className="fw700">Three strikes net rule</strong> has been
              proposed in a front against illegal music file sharing.
            </p>
            <div className="group-13 group">
              <img
                className="layer-37"
                src="images/layer_49_copy.png"
                alt=""
                width={20}
                height={32}
              />
              <div className="shape-37-holder"><a href="">read more</a></div>
            </div>
          </div>
          <div className="news4 group">
            <img
              className="layer-34"
              src="images/layer_34.jpg"
              alt=""
              width={160}
              height={74}
            />
            <p className="text-26">
              <strong className="fw700">
                Jenson Button triumphant in Formula 1{" "}
              </strong>
              after what can only be described as a shaky start.
            </p>
            <div className="group-13-copy-3 group">
              <img
                className="layer-37-copy-3"
                src="images/layer_49_copy.png"
                alt=""
                width={20}
                height={32}
              />
              <div className="shape-37-copy-3-holder"><a href="">read more</a></div>
            </div>
          </div>
        </div>
        <div className="col-17">
          <div className="news2">
            <img
              className="layer-32"
              src="images/layer_32.jpg"
              alt=""
              width={160}
              height={74}
            />
            <p className="text-28">
              <strong className="fw700">The Catholic Church opens</strong> its
              door in the Vatican, to a flood of discontented Anglicans.
            </p>
            <div className="group-13-copy group">
              <img
                className="layer-37-copy"
                src="images/layer_49_copy.png"
                alt=""
                width={20}
                height={32}
              />
              <div className="shape-37-copy-holder"><a href="">read more</a></div>
            </div>
          </div>
          <div className="news5 group">
            <img
              className="layer-35"
              src="images/layer_35.jpg"
              alt=""
              width={160}
              height={74}
            />
            <p className="text-30">
              <strong className="fw700">iTunes for theatre service</strong>{" "}
              marks a pivotal switch for an otherwise, traditional profession.
            </p>
            <div className="group-13-copy-4 group">
              <img
                className="layer-37-copy-4"
                src="images/layer_49_copy.png"
                alt=""
                width={20}
                height={32}
              />
              <div className="shape-37-copy-4-holder"><a href="">read more</a></div>
            </div>
          </div>
        </div>
        <div className="col-18">
          <div className="news3">
            <img
              className="layer-33"
              src="images/layer_33.jpg"
              alt=""
              width={160}
              height={74}
            />
            <p className="text-32">
              <strong className="fw700">An increase in game</strong> addiction
              is attributed to a wide spread break down in social interaction.
            </p>
            <div className="group-13-copy-2 group">
              <img
                className="layer-37-copy-2"
                src="images/layer_49_copy.png"
                alt=""
                width={20}
                height={32}
              />
              <div className="shape-37-copy-2-holder"><a href="">read more</a></div>
            </div>
          </div>
          <div className="news6 group">
            <img
              className="layer-36"
              src="images/layer_36.jpg"
              alt=""
              width={160}
              height={74}
            />
            <p className="text-34">
              <strong className="fw700">Professor jailed for stealing</strong>{" "}
              and selling skulls from a series of burial grounds in China.
            </p>
            <div className="group-13-copy-5 group">
              <img
                className="layer-37-copy-5"
                src="images/layer_49_copy.png"
                alt=""
                width={20}
                height={32}
              />
              <div className="shape-37-copy-5-holder"><a href="">read more</a></div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div className="advertisment-250 match-height group">
      <div className="col-5">
        <img
          className="advertisment-2"
          src="images/advertisment.png"
          alt="Advertisment"
          width={203}
          height={26}
          title="Advertisment"
        />
        <img
          className="space"
          src="images/space.png"
          alt="Space"
          width={174}
          height={65}
          title="Space"
        />
        <img
          className="text-36"
          src="images/250x250.png"
          alt="250X250"
          width={160}
          height={32}
          title="250X250"
        />
      </div>
      <div className="col-6">
        <img
          className="advertisment-3"
          src="images/advertisment.png"
          alt="Advertisment"
          width={203}
          height={26}
          title="Advertisment"
        />
        <img
          className="space-2"
          src="images/space.png"
          alt="Space"
          width={174}
          height={65}
          title="Space"
        />
        <img
          className="text-37"
          src="images/250x250.png"
          alt="250X250"
          width={160}
          height={32}
          title="250X250"
        />
      </div>
    </div>
    <div className="presenter-of-the-month group">
      <div className="row-16 group">
        <img
          className="layer-47"
          src="images/layer_47_copy.jpg"
          alt=""
          width={26}
          height={40}
        />
        <img
          className="text-38"
          src="images/presenter_of_the_month.png"
          alt="Presenter  of the Month"
          width={208}
          height={16}
          title="Presenter  of the Month"
        />
      </div>
      <div className="row-9 group">
        <div className="wrapper-9">
          <div className="col-4">
            <p className="text-39">Preasenter of the month heading text</p>
            <p className="text-40">
              iTunes for theatre service marks a pivotal switch for an
              otherwise, traditional profession. iTunes for theatre service
              marks a pivotal switch for an otherwise, traditional profession.
            </p>
          </div>
          <img
            className="shape-38-copy"
            src="images/shape_38_copy.png"
            alt=""
          />
        </div>
        <img
          className="shape-39"
          src="images/shape_39.png"
          alt=""
          width={14}
          height={16}
        />
      </div>
    </div>
    <div className="row-6 match-height group">
      <div className="ringtones">
        <div className="row-17 group">
          <img
            className="layer-47-copy"
            src="images/layer_47_copy.jpg"
            alt=""
            width={26}
            height={40}
          />
          <img
            className="text-41"
            src="images/get_ringtones.png"
            alt="Get Ringtones"
            width={126}
            height={19}
            title="Get Ringtones"
          />
        </div>
        <div className="col-14 group">
          <div className="group-15">
            <div className="row-21 group">
              <div className="col-24">
                <p className="text-42">Ringtone name</p>
                <img
                  className="layer-50"
                  src="images/layer_50.jpg"
                  alt=""
                  width={63}
                  height={15}
                />
              </div>
              <p className="text-43">
                <span className="color000000">In</span> Hiphop
              </p>
            </div>
            <div className="row-11 group">
              <p className="text-44">
                <strong className="text-style">15,472</strong> downloads
              </p>
              <div className="shape-42-copy-holder"><a href="">Download</a></div>
              <div className="shape-42-copy-2-holder">
                <img
                  className="layer-51"
                  src="images/layer_51.png"
                  alt=""
                  width={10}
                  height={10}
                />
              </div>
            </div>
          </div>
          <div className="group-15-copy group">
            <div className="row-22 group">
              <div className="col-25">
                <p className="text-45">Ringtone name</p>
                <img
                  className="layer-50-copy"
                  src="images/layer_50.jpg"
                  alt=""
                  width={63}
                  height={15}
                />
              </div>
              <p className="text-46">
                <span className="color000000">In</span> Hiphop
              </p>
            </div>
            <div className="row-12 group">
              <p className="text-47">
                <strong className="text-style">15,472</strong> downloads
              </p>
              <div className="shape-42-copy-4-holder"><a href="">Download</a></div>
              <div className="shape-42-copy-3-holder">
                <img
                  className="layer-51-copy"
                  src="images/layer_51.png"
                  alt=""
                  width={10}
                  height={10}
                />
              </div>
            </div>
          </div>
          <div className="group-15-copy-2 group">
            <div className="row-23 group">
              <div className="col-26">
                <p className="text-49">Ringtone name</p>
                <img
                  className="layer-50-copy-2"
                  src="images/layer_50.jpg"
                  alt=""
                  width={63}
                  height={15}
                />
              </div>
              <p className="text-50">
                <span className="color000000">In</span> Hiphop
              </p>
            </div>
            <div className="row-13 group">
              <p className="text-51">
                <strong className="text-style">15,472</strong> downloads
              </p>
              <div className="shape-42-copy-6-holder"><a href="">Download</a></div>
              <div className="shape-42-copy-5-holder">
                <img
                  className="layer-51-copy-2"
                  src="images/layer_51.png"
                  alt=""
                  width={10}
                  height={10}
                />
              </div>
            </div>
          </div>
          <div className="row-24 group">
            <img
              className="layer-49-copy"
              src="images/layer_49_copy.png"
              alt=""
              width={20}
              height={32}
            />
            <p className="text-53"><a href="">View All</a></p>
          </div>
        </div>
      </div>
      <div className="poll">
        <div className="row-18 group">
          <img
            className="layer-47-copy-2"
            src="images/layer_47_copy.jpg"
            alt=""
            width={26}
            height={40}
          />
          <img
            className="text-54"
            src="images/poll_question.png"
            alt="Poll Question"
            width={117}
            height={18}
            title="Poll Question"
          />
        </div>
        <div className="col-15 group">
          <div className="shape-45-holder">What Your Favourite Gadget?</div>
          <div className="row-20 group">
            <div className="col-23">
              <div className="shape-41" />
              <div className="shape-41-copy-holder">
                <div className="shape-41-copy-4" />
              </div>
              <div className="shape-41-copy-2" />
              <div className="shape-41-copy-3" />
            </div>
            <p className="text-56">
              Camera
              <br />
              Laptop
              <br />
              MP3 player
              <br />
              Mobile/Cell
            </p>
          </div>
          <div className="row-8 group">
            <img
              className="layer-49"
              src="images/layer_49_copy.png"
              alt=""
              width={20}
              height={32}
            />
            <div className="shape-42-holder"><a href="">Submit</a></div>
            <p className="text-57">
              <a href="#">Previous Polls</a>
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
    )
}
export default Fourthpage